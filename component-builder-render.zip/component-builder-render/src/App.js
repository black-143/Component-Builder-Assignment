import "./App.css";
import ComponentRender from "./lib/component-renderer/component-render";
import ComponentBuilder from "./lib/component-builder/components/component-builder/component-builder";
function App() {
  return (
    <div className="App">
      <ComponentBuilder/>
    </div>
  );
}
export default App;